"""BrowserGuard FastAPI package."""
