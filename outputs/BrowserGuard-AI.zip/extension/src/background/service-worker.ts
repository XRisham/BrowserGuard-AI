import { getSettings, record } from "../storage";
import { localDecision } from "../classifier/safety";
import { classifyWithApi } from "../services/api";
const seen=new Map<number,string>();
const bypasses=new Map<string,number>();
chrome.runtime.onMessage.addListener((message:{type:string;url:string}, sender) => {
  if (message.type !== "BYPASS" || !sender.tab?.id) return;
  bypasses.set(message.url, Date.now() + 10 * 60 * 1000);
  chrome.tabs.update(sender.tab.id, { url: message.url });
});
chrome.runtime.onMessage.addListener((message:{type:string;text:string;title:string;url:string}, sender) => { if(message.type!=="SCAN" || !sender.tab?.id) return; const id=sender.tab.id, fingerprint=`${message.url}:${message.text.length}:${message.text.slice(0,64)}`; if(seen.get(id)===fingerprint) return; seen.set(id,fingerprint); void (async()=>{ const settings=await getSettings(); if(!settings.enabled) return; const until=bypasses.get(message.url)??0; if(until>Date.now()) { await record("Temporary access used"); return; } bypasses.delete(message.url); let decision=localDecision(message.url,message.text,settings); if(settings.processingMode==="api") { try { decision=await classifyWithApi(message.url,message.title,message.text,settings); } catch { /* local result remains available */ } } await record(decision==="BLOCK"?"Content blocked":decision==="WARN"?"Safety warning":"Website scanned",decision==="BLOCK"?"block":decision==="WARN"?"warn":"scan"); if(decision==="BLOCK") chrome.tabs.update(id,{url:chrome.runtime.getURL(`block.html?url=${encodeURIComponent(message.url)}`)}); })(); });
