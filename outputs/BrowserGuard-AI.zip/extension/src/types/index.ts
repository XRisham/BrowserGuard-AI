export type Sensitivity = "LOW" | "MEDIUM" | "HIGH" | "STRICT";
export type Settings = { enabled:boolean; sensitivity:Sensitivity; scanText:boolean; scanImages:boolean; strictMode:boolean; processingMode:"local"|"api"; apiEndpoint:string; timeoutMs:number; confidenceThreshold:number; blocklist:string[]; allowlist:string[]; password?:{salt:string; hash:string}; };
export type Stats = { pagesScanned:number; pagesBlocked:number; imagesAnalyzed:number; warnings:number; recent:{time:string; event:string}[] };
export const defaults: Settings = {enabled:true,sensitivity:"HIGH",scanText:true,scanImages:false,strictMode:false,processingMode:"local",apiEndpoint:"http://127.0.0.1:8000",timeoutMs:3000,confidenceThreshold:0.65,blocklist:[],allowlist:[]};
export const defaultStats: Stats = {pagesScanned:0,pagesBlocked:0,imagesAnalyzed:0,warnings:0,recent:[]};
