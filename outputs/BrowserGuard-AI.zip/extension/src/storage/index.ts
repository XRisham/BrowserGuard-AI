import { defaults, defaultStats, type Settings, type Stats } from "../types";
const get = <T,>(key:string, fallback:T):Promise<T> => chrome.storage.local.get(key).then(value => (value[key] as T | undefined) ?? fallback);
export const getSettings = () => get<Settings>("settings", defaults);
export const saveSettings = (settings:Settings) => chrome.storage.local.set({settings});
export const getStats = () => get<Stats>("stats", defaultStats);
export async function record(event:string, kind:"scan"|"block"|"warn"="scan"):Promise<void> { const stats=await getStats(); stats.pagesScanned += kind === "scan" ? 1:0; stats.pagesBlocked += kind === "block" ? 1:0; stats.warnings += kind === "warn" ? 1:0; stats.recent=[{time:new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}),event},...stats.recent].slice(0,20); await chrome.storage.local.set({stats}); }
export const clearData = () => chrome.storage.local.clear();
