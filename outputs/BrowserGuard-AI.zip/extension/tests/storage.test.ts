import {expect,it}from"vitest";import{defaultStats}from"../src/types";it("starts statistics locally",()=>expect(defaultStats.pagesScanned).toBe(0));
