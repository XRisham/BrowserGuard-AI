import { describe,expect,it } from "vitest";
import { domainMatches,localDecision } from "../src/classifier/safety";
import { defaults } from "../src/types";
describe("classifier",()=>{it("handles wildcard blocklists",()=>expect(domainMatches("a.example.org",["*.example.org"])).toBe(true));it("blocks synthetic unsafe fixture",()=>expect(localDecision("https://x.test","unsafe_test",defaults)).toBe("BLOCK"));});
