import {expect,it}from"vitest";import{localDecision}from"../src/classifier/safety";import{defaults}from"../src/types";
it("allowlist wins outside strict mode",()=>expect(localDecision("https://good.test","unsafe_test",{...defaults,allowlist:["good.test"]})).toBe("ALLOW"));
