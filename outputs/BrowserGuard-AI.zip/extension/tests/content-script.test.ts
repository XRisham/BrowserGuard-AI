import {expect,it}from"vitest";it("bounds extracted content behavior",()=>expect("x".repeat(10001).slice(0,10000)).toHaveLength(10000));
