import {expect,it}from"vitest";import{defaults}from"../src/types";it("uses local mode by default",()=>expect(defaults.processingMode).toBe("local"));
