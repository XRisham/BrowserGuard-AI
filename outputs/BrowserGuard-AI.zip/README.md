# BrowserGuard AI

[![Backend](https://github.com/BrowserGuard-AI/BrowserGuard-AI/actions/workflows/backend-tests.yml/badge.svg)](../../actions) [![Extension](https://github.com/BrowserGuard-AI/BrowserGuard-AI/actions/workflows/extension-tests.yml/badge.svg)](../../actions) [![Python](https://img.shields.io/badge/Python-3.11%2B-blue)](https://python.org) [![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)](https://typescriptlang.org) [![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

BrowserGuard AI is a privacy-conscious Chrome and Edge extension plus a FastAPI safety service. It combines a trained text model, lightweight image heuristics, transparent rules, and user controls. It never stores page text or images; local statistics are anonymous.

## Features

- Manifest V3 React/TypeScript extension: popup, onboarding, dashboard, settings and block page.
- ML text classification using a reproducible TF-IDF + Logistic Regression pipeline.
- In-memory image analysis, configurable safety aggregation, block/allow lists, temporary bypasses, and Web Crypto-protected settings.
- Request limits, rate limiting, secure headers, restrictive CORS, validation and no sensitive-content logging.

## Architecture

```mermaid
flowchart TD
  A[Website] --> B[Extension content script]
  B --> C[Minimum text extraction]
  C --> D[Text ML classifier]
  C --> E[Image classifier]
  D --> F[Safety engine]
  E --> F
  F --> G{Decision}
  G -->|ALLOW| H[Continue]
  G -->|WARN/BLOCK| I[Warning/block page]
```

## Quick start

```sh
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate   Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python -m ml.training.train_text_model
uvicorn app.main:app --reload
```

```sh
cd extension
npm install
npm run build
```

Load `extension/dist` at `chrome://extensions` or `edge://extensions`: enable Developer mode, choose **Load unpacked**, select that directory, and pin BrowserGuard AI. Set the API endpoint in Settings when using API processing.

## Development and testing

```sh
cd backend && pytest
cd extension && npm test && npm run build
docker compose up --build
```

The training fixture is deliberately small, synthetic, and non-explicit. Run `python -m ml.training.train_text_model` to create the local demo model and `python -m ml.evaluation.evaluate` for measured metrics on that fixture. Those results are not representative of production safety performance.

The included image adapter is deliberately conservative and only supplies an in-memory visual-quality signal; it is **not** a validated semantic safety model. A production semantic image classifier requires a licensed, consented and independently evaluated training corpus, which this repository intentionally does not fabricate.

## Privacy and security

Only bounded text excerpts and optional image bytes are sent to the configured API; neither is persisted. Local-only mode avoids API calls. Password verifiers use PBKDF2 Web Crypto with a per-password random salt (the browser extension cannot use Argon2 without a WASM dependency). See [docs/privacy.md](docs/privacy.md) and [docs/security.md](docs/security.md).

## Repository guide

- `extension/` — MV3 user interface and browser-side safety controls.
- `backend/` — FastAPI service and inference adapters.
- `ml/` — reproducible data preparation, training, evaluation and inference.
- `docs/` — API, architecture, privacy, security and contributor guidance.
- `screenshots/README.md` — instructions for adding real screenshots after installation.

## Roadmap

- [ ] Firefox support
- [ ] Fully local ONNX inference
- [ ] Additional languages and parental profiles
- [ ] Model quantization and threat-intelligence integrations

Contributions are welcome; see [CONTRIBUTING.md](CONTRIBUTING.md). Licensed under [MIT](LICENSE).
